# frontend voor designers - opdracht 3

JSON van de movies data staat ook hier:
deze uri kun je gebruiken voor een van de use case voor opdracht 3.
[https://zeijls.github.io/frontendvoordesigners/opdracht3/json/movies.json](https://zeijls.github.io/frontendvoordesigners/opdracht3/V3)

De JSON data is ook los, per film of genre of actors te gebruiken. Check die [hier](https://github.com/KoopReynders/frontendvoordesigners/tree/master/opdracht3/json).
